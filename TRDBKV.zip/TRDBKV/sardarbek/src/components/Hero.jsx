function Hero() {
  return (
    <section className="hero">
      <div className="hero-content">
        <h2>Отдых вашей мечты на берегу Иссык-Куля</h2>
        <p>9 уникальных номеров с видом на озеро и горы</p>
        <button>Забронировать номер</button>
      </div>
    </section>
  );
}

export default Hero;