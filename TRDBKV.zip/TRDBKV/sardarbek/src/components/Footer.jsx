function Footer() {
  return (
    <footer className="fot1">
      <h1>Boomerang</h1>
      <p>Лучший отдых на Иссык-Куле</p>

      <h2>Наши контакты</h2>
      <p>Иссык-Куль, Чолпон-Ата</p>
      <p>+996 (555) 123-456</p>
      <p>info@boomerang-hotel.kg</p>
    </footer>
  );
}

export default Footer;