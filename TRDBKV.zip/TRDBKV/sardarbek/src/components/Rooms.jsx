function Rooms() {
  const handleBooking = () => {
    alert("Бронирование...");
  };

  return (
    <>
      <h1 className="qw2">Наши номера</h1>

      <div className="room-image">
        <div>
          <img
            src="https://images.unsplash.com/photo-1566665797739-1674de7a421a"
            alt="room"
          />
          <button onClick={handleBooking}>Забронировать</button>
        </div>

        <div>
          <img
            src="https://images.unsplash.com/photo-1613977257363-707ba9348227"
            alt="room"
          />
          <button onClick={handleBooking}>Забронировать</button>
        </div>

        <div>
          <img
            src="https://images.unsplash.com/photo-1611892440504-42a792e24d32"
            alt="room"
          />
          <button onClick={handleBooking}>Забронировать</button>
        </div>
      </div>
    </>
  );
}

export default Rooms;