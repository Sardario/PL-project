function About() {
  return (
    <>
      <h1 className="qw1">Добро пожаловать в отель Boomerang</h1>

      <div className="about-image">
        <img
          src="https://images.unsplash.com/photo-1544551763-46a013bb70d5"
          alt="Отель"
        />
        <p>
          Отель Boomerang расположен на берегу Иссык-Куля. Комфортные номера и
          красивый вид на горы.
        </p>
        <p>
          В нашем отеле 9 номеров для туристов и семей с детьми.
        </p>
      </div>
    </>
  );
}

export default About;   