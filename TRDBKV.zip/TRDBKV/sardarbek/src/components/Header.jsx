function Header() {
  return (
    <header className="container">
      <h1>Boomerang</h1>
      <p>Отель на берегу Иссык-Куля</p>

      <div className="heading">
        <a href="/">Главная</a>
        <a href="/booking">Бронирование</a>
      </div>
    </header>
  );
}

export default Header;